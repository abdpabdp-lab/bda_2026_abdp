# Funciones de subida y metadatos con boto3
import json
import logging
from pathlib import Path
from datetime import datetime
import boto3
from botocore.exceptions import ClientError
from config import AWS_REGION, S3_BUCKET_NAME, S3_PREFIX_PREDICCION

logger = logging.getLogger(__name__)


class S3Manager:
    def __init__(self, bucket_name: str = S3_BUCKET_NAME, region: str = AWS_REGION):
        self.bucket_name = bucket_name
        self.region = region
        self.s3 = boto3.client("s3", region_name=self.region)

    def crear_bucket_si_no_existe(self) -> None:
        """Crea el bucket en S3 si aún no existe en la cuenta."""
        try:
            if self.region == "us-east-1":
                self.s3.create_bucket(Bucket=self.bucket_name)
            else:
                self.s3.create_bucket(
                    Bucket=self.bucket_name,
                    CreateBucketConfiguration={"LocationConstraint": self.region},
                )
            logger.info(f"Bucket '{self.bucket_name}' creado en {self.region}.")
        except ClientError as e:
            error_code = e.response["Error"]["Code"]
            if error_code in ("BucketAlreadyOwnedByYou", "BucketAlreadyExists"):
                logger.info(f"El bucket '{self.bucket_name}' ya existe y está listo.")
            else:
                logger.error(f"Error crítico creando el bucket: {e}")
                raise

    def subir_fichero_local(self, ruta_local: Path, s3_key: str, metadata: dict) -> None:
        """Sube un archivo CSV desde disco en crudo adjuntando metadatos."""
        if not ruta_local.exists():
            raise FileNotFoundError(f"No se encuentra el archivo local: {ruta_local}")

        self.s3.upload_file(
            Filename=str(ruta_local),
            Bucket=self.bucket_name,
            Key=s3_key,
            ExtraArgs={"Metadata": metadata},
        )
        logger.info(f"Archivo subido: s3://{self.bucket_name}/{s3_key}")

    def subir_prediccion_json(self, id_playa: str, datos_json: list | dict) -> None:
        """Sube el JSON desde RAM aplicando particionamiento temporal estilo Hive."""
        ahora = datetime.now()
        s3_key = (
            f"{S3_PREFIX_PREDICCION}/"
            f"year={ahora:%Y}/month={ahora:%m}/day={ahora:%d}/"
            f"pred_playa_{id_playa}_{ahora:%H%M%S}.json"
        )

        self.s3.put_object(
            Bucket=self.bucket_name,
            Key=s3_key,
            Body=json.dumps(datos_json, ensure_ascii=False).encode("utf-8"),
            ContentType="application/json",
            Metadata={"id_playa": str(id_playa), "fuente": "aemet"},
        )
        logger.info(f"Predicción guardada: s3://{self.bucket_name}/{s3_key}")
