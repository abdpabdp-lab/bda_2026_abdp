# Carga de .env y constantes globales

import os
from pathlib import Path
from dotenv import load_dotenv, find_dotenv

# Cargar variables de entorno desde la raíz del proyecto
load_dotenv(find_dotenv(), override=True)

# Rutas locales del proyecto
BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
FILE_MITECO = DATA_DIR / "playas.csv"
FILE_AEMET = DATA_DIR / "playas_codigos.csv"

# Configuración de AWS S3
AWS_REGION = os.getenv("AWS_DEFAULT_REGION", "us-east-1")
S3_BUCKET_NAME = os.getenv("S3_BUCKET_NAME", "datalake-turismo-bronce-abdp")

# Claves S3 (Capa Bronce)
S3_KEY_MITECO = "bronce/catalogos/miteco_playas/v1/playas.csv"
S3_KEY_AEMET_CODIGOS = "bronce/catalogos/aemet_codigos/v1/playas_codigos.csv"
S3_PREFIX_PREDICCION = "bronce/meteorologia/aemet_prediccion_playas"

# Configuración de AEMET y reglas de negocio
AEMET_API_KEY = os.getenv("AEMET_API_KEY")
AEMET_BASE_URL = "https://aemet.es"
PROVINCIA_OBJETIVO = os.getenv("PROVINCIA_OBJETIVO", "Alicante")
MAX_PLAYAS = int(os.getenv("MAX_PLAYAS", 15))
RATE_LIMIT_SLEEP = 1.5  # Pausa obligatoria entre peticiones (segundos)
