# Orquestador principal del pipeline

import time
import logging
from config import (
    FILE_MITECO,
    FILE_AEMET,
    S3_KEY_MITECO,
    S3_KEY_AEMET_CODIGOS,
    PROVINCIA_OBJETIVO,
    MAX_PLAYAS,
    RATE_LIMIT_SLEEP,
)
from s3_manager import S3Manager
from aemet_client import AemetClient, obtener_ids_playas_provincia

# Configuración de logs limpia para producción
# Registro de eventos con logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
logger = logging.getLogger(__name__)


def ejecutar_pipeline() -> None:
    logger.info("=== INICIO PIPELINE INGESTA CAPA BRONCE (S3) ===")

    # 1. Inicializar gestor S3 y asegurar bucket
    s3_mgr = S3Manager()
    s3_mgr.crear_bucket_si_no_existe()

    # 2. Ingesta de catálogos estáticos desde disco (Raw)
    logger.info("Subiendo catálogos maestros a Capa Bronce...")
    s3_mgr.subir_fichero_local(
        ruta_local=FILE_MITECO,
        s3_key=S3_KEY_MITECO,
        metadata={"origen": "miteco", "version": "v1"},
    )
    s3_mgr.subir_fichero_local(
        ruta_local=FILE_AEMET,
        s3_key=S3_KEY_AEMET_CODIGOS,
        metadata={"origen": "aemet", "version": "v1"},
    )

    # 3. Obtener IDs de playas de la provincia seleccionada
    ids_playas = obtener_ids_playas_provincia(
        ruta_miteco=FILE_MITECO,
        ruta_aemet=FILE_AEMET,
        provincia=PROVINCIA_OBJETIVO,
        limite=MAX_PLAYAS,
    )

    # 4. Ingesta de predicciones meteorológicas (API AEMET -> RAM -> S3)
    aemet = AemetClient()
    total = len(ids_playas)

    for idx, id_playa in enumerate(ids_playas, start=1):
        logger.info(f"[{idx}/{total}] Procesando playa ID: {id_playa}...")
        datos_prediccion = aemet.descargar_prediccion_playa(id_playa)

        if datos_prediccion:
            s3_mgr.subir_prediccion_json(id_playa=id_playa, datos_json=datos_prediccion)

        # Respetar límite de tasa entre llamadas
        if idx < total:
            time.sleep(RATE_LIMIT_SLEEP)

    logger.info("=== PIPELINE FINALIZADO CON ÉXITO ===")


if __name__ == "__main__":
    ejecutar_pipeline()
