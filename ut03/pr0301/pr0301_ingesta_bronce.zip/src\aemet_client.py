# Cruce de catálogos y cliente REST de AEMET

import time
import logging
from pathlib import Path
import pandas as pd
import requests
from config import AEMET_API_KEY, AEMET_BASE_URL

logger = logging.getLogger(__name__)


def obtener_ids_playas_provincia(
    ruta_miteco: Path, ruta_aemet: Path, provincia: str, limite: int = 15
) -> list[str]:
    """Cruza ambos CSV por código INE y devuelve hasta 'limite' IDs de playa de AEMET."""
    df_miteco = pd.read_csv(
        ruta_miteco, sep=",", encoding="utf-8", dtype={"Código_IN": str}
    )
    df_aemet = pd.read_csv(
        ruta_aemet,
        sep=";",
        encoding="latin1",
        dtype={"ID_PLAYA": str, "ID_MUNICIPIO": str},
    )

    codigos_ine = df_miteco[df_miteco["Provincia"] == provincia]["Código_IN"].unique()
    playas_filtradas = df_aemet[df_aemet["ID_MUNICIPIO"].isin(codigos_ine)].head(limite)

    lista_ids = playas_filtradas["ID_PLAYA"].tolist()
    logger.info(
        f"Provincia '{provincia}': {len(lista_ids)} playas seleccionadas para ingesta."
    )
    return lista_ids


class AemetClient:
    def __init__(self, api_key: str = AEMET_API_KEY):
        if not api_key:
            raise ValueError("Falta AEMET_API_KEY en el archivo .env")
        self.headers = {"api_key": api_key}

    def descargar_prediccion_playa(self, id_playa: str) -> list | None:
        """Ejecuta el flujo de doble salto de AEMET controlando Rate Limiting (429)."""
        url_endpoint = f"{AEMET_BASE_URL}/{id_playa}"

        try:
            # Salto 1: Solicitar URL temporal
            res1 = requests.get(url_endpoint, headers=self.headers, timeout=15)

            if res1.status_code == 429:
                logger.warning(f"HTTP 429 en playa {id_playa}. Esperando 15s...")
                time.sleep(15)
                res1 = requests.get(url_endpoint, headers=self.headers, timeout=15)

            res1.raise_for_status()
            control = res1.json()
            url_datos = control.get("datos")

            if not url_datos:
                logger.warning(
                    f"Sin datos para playa {id_playa}: {control.get('descripcion')}"
                )
                return None

            # Salto 2: Descargar JSON real forzado a latin1
            res2 = requests.get(url_datos, timeout=15)
            res2.raise_for_status()
            res2.encoding = "latin1"
            return res2.json()

        except requests.RequestException as e:
            logger.error(f"Error consultando AEMET para playa {id_playa}: {e}")
            return None
